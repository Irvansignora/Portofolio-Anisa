import { motion, type Variants } from 'framer-motion';
import { 
  Heart, BookOpen, Sparkles, Star, Users, Lightbulb, 
  MessageCircle, Palette, GraduationCap, Gamepad2, 
  Phone, Mail, MapPin, ArrowRight, Quote, Menu, X
} from 'lucide-react';
import { useState, useEffect } from 'react';

// Animation variants
const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 60 },
  visible: { 
    opacity: 1, 
    y: 0, 
    transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] as const } 
  }
};

const fadeInRight: Variants = {
  hidden: { opacity: 0, x: 60 },
  visible: { 
    opacity: 1, 
    x: 0, 
    transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] as const } 
  }
};

const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15, delayChildren: 0.2 }
  }
};

const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { 
    opacity: 1, 
    scale: 1, 
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const } 
  }
};

// Floating particles component
const FloatingParticles = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-3 h-3 rounded-full"
          style={{
            background: i % 3 === 0 ? 'rgba(255, 107, 157, 0.4)' : i % 3 === 1 ? 'rgba(255, 154, 86, 0.4)' : 'rgba(255, 230, 109, 0.4)',
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, Math.random() * 20 - 10, 0],
            rotate: [0, 360],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 4 + Math.random() * 4,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
};

// Navigation component
const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Beranda', href: '#hero' },
    { name: 'Tentang', href: '#about' },
    { name: 'Keahlian', href: '#expertise' },
    { name: 'Nilai', href: '#values' },
    { name: 'Metode', href: '#approach' },
    { name: 'Kontak', href: '#contact' },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? 'glass py-3 shadow-lg' : 'py-5 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <motion.a 
          href="#hero"
          className="text-xl font-bold gradient-text"
          whileHover={{ scale: 1.05 }}
        >
          Anisa Fitriani
        </motion.a>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <motion.a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-gray-700 hover:text-pink-500 transition-colors relative group"
              whileHover={{ y: -2 }}
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-pink-500 to-orange-400 group-hover:w-full transition-all duration-300" />
            </motion.a>
          ))}
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <motion.div
        initial={false}
        animate={{ height: isMobileMenuOpen ? 'auto' : 0, opacity: isMobileMenuOpen ? 1 : 0 }}
        className="md:hidden overflow-hidden bg-white/95 backdrop-blur-lg"
      >
        <div className="px-6 py-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-gray-700 hover:text-pink-500 transition-colors py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {link.name}
            </a>
          ))}
        </div>
      </motion.div>
    </motion.nav>
  );
};

// Hero Section
const HeroSection = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-pink-100 via-orange-50 to-yellow-50 animate-gradient" />
      
      {/* Decorative Blobs */}
      <motion.div 
        className="absolute top-20 left-10 w-72 h-72 bg-pink-300/30 blob"
        animate={{ 
          scale: [1, 1.2, 1], 
          rotate: [0, 180, 360],
          borderRadius: ['40% 60% 70% 30% / 40% 50% 60% 50%', '60% 40% 30% 70% / 60% 30% 70% 40%', '40% 60% 70% 30% / 40% 50% 60% 50%']
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      />
      <motion.div 
        className="absolute bottom-20 right-10 w-96 h-96 bg-orange-300/30 blob-2"
        animate={{ 
          scale: [1, 1.3, 1], 
          rotate: [360, 180, 0],
          borderRadius: ['60% 40% 30% 70% / 60% 30% 70% 40%', '30% 70% 70% 30% / 30% 30% 70% 70%', '60% 40% 30% 70% / 60% 30% 70% 40%']
        }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      />
      <motion.div 
        className="absolute top-1/2 left-1/3 w-48 h-48 bg-yellow-300/30 blob-3"
        animate={{ 
          scale: [1, 1.4, 1], 
          x: [0, 50, 0],
          y: [0, -30, 0]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />

      <FloatingParticles />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-32 w-full">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          {/* Text Content */}
          <motion.div 
            className="flex-1 text-center lg:text-left"
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
          >
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full shadow-lg mb-6">
              <Sparkles className="w-4 h-4 text-pink-500" />
              <span className="text-sm font-medium text-gray-700">Pendidik Profesional</span>
            </motion.div>
            
            <motion.h1 
              variants={fadeInUp}
              className="hero-title text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
            >
              <span className="gradient-text">Anisa</span>
              <br />
              <span className="text-gray-800">Fitriani</span>
            </motion.h1>
            
            <motion.p 
              variants={fadeInUp}
              className="text-xl md:text-2xl text-gray-600 mb-8 font-light"
            >
              Pendidik PAUD & Guru Ngaji Anak
              <span className="block text-pink-500 font-medium mt-2">Penuh Cinta & Dedikasi</span>
            </motion.p>
            
            <motion.div variants={fadeInUp} className="flex flex-wrap gap-4 justify-center lg:justify-start">
              <motion.a
                href="#contact"
                className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-pink-500 to-orange-400 text-white rounded-full font-semibold shadow-lg btn-shine"
                whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(255, 107, 157, 0.4)' }}
                whileTap={{ scale: 0.98 }}
              >
                Hubungi Saya
                <ArrowRight className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="#about"
                className="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-700 rounded-full font-semibold shadow-lg border border-gray-100"
                whileHover={{ scale: 1.05, backgroundColor: '#FFF5F7' }}
                whileTap={{ scale: 0.98 }}
              >
                Kenali Lebih Dekat
              </motion.a>
            </motion.div>
          </motion.div>

          {/* Profile Image */}
          <motion.div 
            className="flex-1 flex justify-center"
            initial="hidden"
            animate="visible"
            variants={fadeInRight}
          >
            <div className="relative">
              {/* Decorative rings */}
              <motion.div 
                className="absolute -inset-4 border-4 border-dashed border-pink-300/50 rounded-3xl"
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute -inset-8 border-2 border-orange-300/30 rounded-[2rem]"
                animate={{ rotate: -360 }}
                transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              />
              
              {/* Main image container */}
              <motion.div 
                className="relative w-80 h-80 md:w-96 md:h-96 rounded-3xl overflow-hidden shadow-2xl"
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.4 }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-pink-500/20 to-transparent z-10" />
                <img 
                  src="anisa.jpg" 
                  alt="Anisa Fitriani"
                  className="w-full h-full object-cover"
                />
              </motion.div>

              {/* Floating badges */}
              <motion.div 
                className="absolute -top-4 -right-4 bg-white px-4 py-2 rounded-full shadow-lg flex items-center gap-2"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <Heart className="w-5 h-5 text-pink-500 fill-pink-500" />
                <span className="text-sm font-medium">Penuh Kasih</span>
              </motion.div>
              
              <motion.div 
                className="absolute -bottom-4 -left-4 bg-white px-4 py-2 rounded-full shadow-lg flex items-center gap-2"
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
              >
                <BookOpen className="w-5 h-5 text-orange-500" />
                <span className="text-sm font-medium">Guru Ngaji</span>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Wave separator */}
      <div className="wave-separator">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path 
            d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" 
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
};

// About Section
const AboutSection = () => {
  const cards = [
    {
      icon: <Users className="w-10 h-10" />,
      title: "Pendidik Profesional",
      description: "Berpengalaman dalam mendidik anak usia dini dengan pendekatan yang menyenangkan dan penuh kasih sayang. Setiap anak adalah bintang yang spesial!",
      color: "from-pink-400 to-pink-600"
    },
    {
      icon: <BookOpen className="w-10 h-10" />,
      title: "Guru Ngaji Anak",
      description: "Membimbing anak-anak mengenal Al-Quran dengan metode yang mudah dipahami dan menyenangkan. Membentuk generasi Qurani yang cinta membaca.",
      color: "from-orange-400 to-orange-600"
    },
    {
      icon: <Heart className="w-10 h-10" />,
      title: "Penuh Energi & Cinta",
      description: "Mengajar dengan hati, menciptakan lingkungan belajar yang positif, dan membangun karakter anak dengan penuh semangat dan keceriaan.",
      color: "from-yellow-400 to-yellow-600"
    }
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-pink-100/50 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-100/50 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="text-center mb-16"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 bg-pink-100 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-pink-500" />
            <span className="text-sm font-medium text-pink-700">Mengenal Saya</span>
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text">Tentang Saya</span>
          </motion.h2>
          <motion.p variants={fadeInUp} className="text-gray-600 max-w-2xl mx-auto text-lg">
            Seorang pendidik yang berdedikasi untuk membentuk generasi muda yang cerdas, 
            berakhlak mulia, dan cinta Al-Quran
          </motion.p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-3 gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
        >
          {cards.map((card, index) => (
            <motion.div
              key={index}
              variants={scaleIn}
              className="group relative"
            >
              <div className="relative bg-white rounded-3xl p-8 shadow-lg border border-gray-100 card-hover overflow-hidden">
                {/* Gradient background on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
                
                {/* Icon */}
                <motion.div 
                  className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${card.color} flex items-center justify-center text-white mb-6 shadow-lg`}
                  whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  {card.icon}
                </motion.div>

                <h3 className="text-xl font-bold text-gray-800 mb-3">{card.title}</h3>
                <p className="text-gray-600 leading-relaxed">{card.description}</p>

                {/* Decorative corner */}
                <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-gradient-to-br from-pink-100 to-orange-100 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-500" />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// Expertise Section
const ExpertiseSection = () => {
  const expertise = [
    { icon: <Palette className="w-8 h-8" />, title: "Pembelajaran PAUD", desc: "Mengembangkan kreativitas dan motorik anak melalui bermain sambil belajar" },
    { icon: <BookOpen className="w-8 h-8" />, title: "Tahsin & Tahfidz", desc: "Membimbing bacaan Al-Quran yang benar dan hafalan dengan metode fun" },
    { icon: <Gamepad2 className="w-8 h-8" />, title: "Metode Kreatif", desc: "Storytelling, games edukatif, dan aktivitas interaktif yang menyenangkan" },
    { icon: <Star className="w-8 h-8" />, title: "Pengembangan Karakter", desc: "Membangun akhlak mulia, kemandirian, dan kepercayaan diri anak" },
    { icon: <MessageCircle className="w-8 h-8" />, title: "Komunikasi Orang Tua", desc: "Kolaborasi aktif dengan orang tua untuk perkembangan optimal anak" },
    { icon: <Lightbulb className="w-8 h-8" />, title: "Manajemen Kelas", desc: "Menciptakan suasana belajar yang kondusif, ceria, dan produktif" },
  ];

  return (
    <section id="expertise" className="py-24 bg-gradient-to-br from-yellow-50 via-orange-50 to-pink-50 relative overflow-hidden">
      {/* Decorative pattern */}
      <div className="absolute inset-0 decorative-dots opacity-30" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="text-center mb-16"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full mb-4">
            <Star className="w-4 h-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-700">Keunggulan</span>
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text">Keahlian & Kompetensi</span>
          </motion.h2>
          <motion.p variants={fadeInUp} className="text-gray-600 max-w-2xl mx-auto text-lg">
            Berbagai kemampuan yang saya miliki untuk memberikan pendidikan terbaik 
            bagi putra-putri Anda
          </motion.p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
        >
          {expertise.map((item, index) => (
            <motion.div
              key={index}
              variants={fadeInUp}
              whileHover={{ y: -8, scale: 1.02 }}
              className="group bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex items-start gap-4">
                <motion.div 
                  className="w-14 h-14 rounded-xl bg-gradient-to-br from-pink-400 to-orange-400 flex items-center justify-center text-white shadow-lg flex-shrink-0"
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  {item.icon}
                </motion.div>
                <div>
                  <h3 className="text-lg font-bold text-gray-800 mb-2 group-hover:text-pink-500 transition-colors">{item.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// Values Section
const ValuesSection = () => {
  const values = [
    { icon: "🌸", title: "Sabar & Telaten", color: "from-pink-400 to-rose-500" },
    { icon: "✨", title: "Inovatif & Kreatif", color: "from-purple-400 to-pink-500" },
    { icon: "💖", title: "Penuh Kasih Sayang", color: "from-rose-400 to-red-500" },
    { icon: "🌟", title: "Energik & Antusias", color: "from-yellow-400 to-orange-500" },
    { icon: "📖", title: "Istiqomah", color: "from-green-400 to-teal-500" },
  ];

  return (
    <section id="values" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-pink-100 to-orange-100 rounded-full blur-3xl opacity-50" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="text-center mb-16"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 bg-rose-100 rounded-full mb-4">
            <Heart className="w-4 h-4 text-rose-500" />
            <span className="text-sm font-medium text-rose-700">Prinsip Hidup</span>
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text">Nilai-Nilai yang Saya Pegang</span>
          </motion.h2>
        </motion.div>

        <motion.div 
          className="flex flex-wrap justify-center gap-4 mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
        >
          {values.map((value, index) => (
            <motion.div
              key={index}
              variants={scaleIn}
              whileHover={{ scale: 1.1, rotate: [-2, 2, -2, 0] }}
              className={`group px-8 py-5 rounded-2xl bg-gradient-to-r ${value.color} text-white shadow-lg cursor-pointer`}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{value.icon}</span>
                <span className="font-semibold">{value.title}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Quote */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
          className="max-w-3xl mx-auto"
        >
          <div className="relative bg-gradient-to-br from-pink-50 to-rose-50 rounded-3xl p-10 border-2 border-dashed border-pink-300">
            <Quote className="absolute top-4 left-4 w-12 h-12 text-pink-300" />
            <Quote className="absolute bottom-4 right-4 w-12 h-12 text-pink-300 rotate-180" />
            
            <p className="text-center text-xl md:text-2xl text-gray-700 font-medium italic leading-relaxed px-8">
              "Setiap anak adalah permata yang berharga. Tugas kita adalah membantunya 
              bersinar dengan keunikan dan potensinya masing-masing!"
            </p>
            <div className="flex justify-center mt-6">
              <motion.div 
                className="flex gap-1"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 text-yellow-400 fill-yellow-400" />
                ))}
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// Approach Section
const ApproachSection = () => {
  const approaches = [
    { 
      number: "01", 
      title: "Belajar Sambil Bermain", 
      desc: "Menciptakan pembelajaran yang menyenangkan melalui permainan edukatif yang menarik dan interaktif",
      icon: <Gamepad2 className="w-6 h-6" />
    },
    { 
      number: "02", 
      title: "Pendekatan Personal", 
      desc: "Memahami keunikan setiap anak dan menyesuaikan metode pembelajaran sesuai gaya belajarnya",
      icon: <Users className="w-6 h-6" />
    },
    { 
      number: "03", 
      title: "Lingkungan Positif", 
      desc: "Membangun suasana kelas yang penuh cinta, rasa aman, dan mendukung eksplorasi kreatif",
      icon: <Heart className="w-6 h-6" />
    },
    { 
      number: "04", 
      title: "Apresiasi & Motivasi", 
      desc: "Memberikan pujian dan semangat untuk setiap pencapaian anak, sekecil apapun itu",
      icon: <Star className="w-6 h-6" />
    },
    { 
      number: "05", 
      title: "Kolaborasi dengan Orang Tua", 
      desc: "Komunikasi rutin untuk mendukung perkembangan anak di rumah dan sekolah secara harmonis",
      icon: <MessageCircle className="w-6 h-6" />
    },
  ];

  return (
    <section id="approach" className="py-24 bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="text-center mb-16"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 rounded-full mb-4">
            <GraduationCap className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-700">Strategi Mengajar</span>
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text-purple">Pendekatan Mengajar Saya</span>
          </motion.h2>
          <motion.p variants={fadeInUp} className="text-gray-600 max-w-2xl mx-auto text-lg">
            Metode pembelajaran yang dirancang khusus untuk memaksimalkan 
            potensi setiap anak
          </motion.p>
        </motion.div>

        <motion.div 
          className="relative"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
        >
          {/* Timeline line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-green-400 via-emerald-400 to-teal-400 rounded-full transform md:-translate-x-1/2" />

          {approaches.map((item, index) => (
            <motion.div
              key={index}
              variants={fadeInUp}
              className={`relative flex items-center gap-8 mb-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
            >
              {/* Content */}
              <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                <motion.div 
                  className="bg-white rounded-2xl p-6 shadow-lg border border-green-100 hover:shadow-xl transition-shadow"
                  whileHover={{ x: index % 2 === 0 ? -5 : 5 }}
                >
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.desc}</p>
                </motion.div>
              </div>

              {/* Number circle */}
              <motion.div 
                className="relative z-10 w-16 h-16 rounded-full bg-gradient-to-br from-green-400 to-teal-500 flex items-center justify-center text-white font-bold text-lg shadow-lg flex-shrink-0"
                whileHover={{ scale: 1.2, rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                {item.icon}
              </motion.div>

              {/* Empty space for alternating layout */}
              <div className="flex-1 hidden md:block" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// Contact Section
const ContactSection = () => {
  const contacts = [
    { icon: <Mail className="w-6 h-6" />, label: "Email", value: "nenganisa322@gmail.com", href: "mailto:nenganisa322@gmail.com" },
    { icon: <Phone className="w-6 h-6" />, label: "Telepon", value: "087832213455", href: "tel:087832213455" },
    { icon: <MapPin className="w-6 h-6" />, label: "Lokasi", value: "Jakarta, Indonesia", href: "#" },
  ];

  return (
    <section id="contact" className="py-24 bg-gradient-to-br from-purple-500 via-pink-500 to-rose-500 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0">
        <motion.div 
          className="absolute top-10 left-10 w-64 h-64 bg-white/10 rounded-full blur-3xl"
          animate={{ scale: [1, 1.5, 1], x: [0, 50, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
        <motion.div 
          className="absolute bottom-10 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl"
          animate={{ scale: [1, 1.3, 1], x: [0, -30, 0] }}
          transition={{ duration: 12, repeat: Infinity }}
        />
      </div>

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="text-center mb-12"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full mb-4">
            <MessageCircle className="w-4 h-4 text-white" />
            <span className="text-sm font-medium text-white">Hubungi Saya</span>
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-4 text-white">
            Mari Berkolaborasi!
          </motion.h2>
          <motion.p variants={fadeInUp} className="text-white/90 text-lg max-w-2xl mx-auto">
            Saya siap membantu mengembangkan potensi putra-putri Anda 
            dengan penuh dedikasi dan keceriaan!
          </motion.p>
        </motion.div>

        <motion.div 
          className="flex flex-wrap justify-center gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
        >
          {contacts.map((contact, index) => (
            <motion.a
              key={index}
              href={contact.href}
              variants={scaleIn}
              whileHover={{ scale: 1.05, y: -5 }}
              whileTap={{ scale: 0.98 }}
              className="group flex items-center gap-4 bg-white/20 backdrop-blur-sm rounded-2xl px-8 py-5 text-white hover:bg-white/30 transition-all"
            >
              <motion.div 
                className="w-12 h-12 rounded-full bg-white/30 flex items-center justify-center"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                {contact.icon}
              </motion.div>
              <div>
                <p className="text-sm text-white/70">{contact.label}</p>
                <p className="font-semibold">{contact.value}</p>
              </div>
            </motion.a>
          ))}
        </motion.div>

        {/* CTA Button */}
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <motion.a
            href="https://wa.me/6287832213455"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-10 py-5 bg-white text-pink-600 rounded-full font-bold text-lg shadow-xl btn-shine"
            whileHover={{ scale: 1.05, boxShadow: '0 25px 50px rgba(0,0,0,0.3)' }}
            whileTap={{ scale: 0.98 }}
          >
            <MessageCircle className="w-6 h-6" />
            Chat via WhatsApp
            <ArrowRight className="w-5 h-5" />
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12 relative overflow-hidden">
      {/* Decorative gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-orange-500/10" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="w-6 h-6 text-pink-400" />
            </motion.div>
            <h3 className="text-2xl font-bold gradient-text">Anisa Fitriani</h3>
            <motion.div
              animate={{ rotate: [360, 0] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="w-6 h-6 text-orange-400" />
            </motion.div>
          </div>
          
          <p className="text-gray-400 mb-2">
            Pendidik yang Membentuk Masa Depan dengan Cinta dan Semangat
          </p>
          <p className="text-gray-500 text-sm">
            © 2026 | Bersama Membangun Generasi Cerdas dan Berakhlak Mulia
          </p>

          {/* Social links decoration */}
          <div className="flex justify-center gap-4 mt-6">
            {[Heart, Star, BookOpen].map((Icon, index) => (
              <motion.div
                key={index}
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center"
                whileHover={{ scale: 1.2, backgroundColor: 'rgba(255,107,157,0.3)' }}
              >
                <Icon className="w-5 h-5" />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

// Main App
function App() {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ExpertiseSection />
      <ValuesSection />
      <ApproachSection />
      <ContactSection />
      <Footer />
    </div>
  );
}

export default App;
